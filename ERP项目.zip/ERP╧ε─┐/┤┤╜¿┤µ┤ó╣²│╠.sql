CREATE PROC PROC_SELECT_PoPut_BY_OrderNumber(@ordernumber nvarchar(200))
AS
	SELECT A.ordernumber,A.date,U.UserName,A.UserID,E.Name AS EntrepotName,R.Name AS ReservoirName,E.ID AS EntrepotID,R.ID AS ReservoirID,A.money,A.state,A.rktime,A.remark  FROM Poput A ,Entrepot E,Reservoir R,Usertable U WHERE A.EntrepotID =E.ID AND A.ReservoirID =R.ID AND A.UserID = U.ID AND A.ordernumber =@ordernumber


EXEC  PROC_SELECT_PoPut_BY_OrderNumber 'CR20181217234354255'

Go

CREATE PROC PROC_SELECT_PoPutDetails_BY_OrderNumber(@ordernumber nvarchar(200))
AS
	SELECT   dbo.Poputdetails.ordernumber, dbo.Commodity.Name, dbo.Poputdetails.Numble, dbo.Poputdetails.CommidityID, 
                dbo.Poputdetails.taxrate, dbo.Poputdetails.discountrate, dbo.Poputdetails.SupplierID, dbo.Poputdetails.money, dbo.Poputdetails.price, 
                dbo.Poputdetails.describe, dbo.Supplier.VendorName
FROM      dbo.Commodity INNER JOIN
                dbo.Poputdetails ON dbo.Commodity.ID = dbo.Poputdetails.CommidityID INNER JOIN
                dbo.Supplier ON dbo.Poputdetails.SupplierID = dbo.Supplier.ID where dbo.Poputdetails.ordernumber = @ordernumber

Go

CREATE PROC PROC_Add_PoPut
@ordernumber nvarchar(200),
@UserID int,
@date date,
@Ponumber nvarchar(200),
@rktime date,
@EntrepotID int,
@ReservoirID int,
@money money,
@yfmoney money,
@type nvarchar(50),
@state nvarchar(50),
@remark nvarchar(2000)
AS
	INSERT INTO Poput VALUES(
	@ordernumber,
	@UserID,
	@date,
@Ponumber,
@rktime,
@EntrepotID ,
@ReservoirID ,
@money ,
@yfmoney ,
@type ,
@state,
@remark)

GO

CREATE PROC PROC_Add_PoPutDetails
@ordernumber nvarchar(200),
@CommidityID int,
@Numble int,
@taxrate float,
@discountrate float,
@SupplierID int,
@price money,
@money money,
@describe nvarchar(100)
AS
INSERT INTO Poputdetails VALUES(@ordernumber,@CommidityID,@Numble,@taxrate,@discountrate,@SupplierID,@price,@money,@describe)

go 

CREATE PROC PROC_Update_Po_State
@table nvarchar(50),
@ordernumber nvarchar(200),
@state nchar(10)
as
Update Po set state=@state where ordernumber = @ordernumber

GO

exec PROC_Update_Po_State 'po', 'BY20181212123245' ,'y'

delete Poputdetails

go

use ERP
go
if exists (select name from sysobjects where name='PROC_Select_PoPut_Query' and type='p')
drop procedure PROC_Select_PoPut_Query
go

create procedure PROC_Select_PoPut_Query
	 @ordernumber nvarchar(200),
	 @starttime nvarchar(100),
	 @endtime nvarchar(100),	 
	 @state nvarchar(50)
	 AS 
	 declare @sql nvarchar(1000)
	 set @sql='select P.ordernumber,P.date,E.Name AS EntrepotName,R.Name AS ReservoirName,U.UserName,P.money,P.state from Poput as P,Entrepot as E,Reservoir as R ,Usertable AS U WHERE P.EntrepotID =E.ID AND P.ReservoirID=R.ID AND P.UserID=U.ID'
	 if(len(@ordernumber)<>0)
	 begin 
		set @sql = @sql+' and P.ordernumber='+@ordernumber+ ' '
	 end 
	 
	 if(len(@starttime)<>0 and len(@endtime)<>0)
	 begin
		set @sql = @sql+' and P.date BETWEEN '+' CONVERT(datetime, '+@starttime+') AND'+' CONVERT(datetime, '+ @endtime+') '
	 end
	  if(len(@state)<>0)
	 begin
		set @sql = @sql+' and P.state = '+@state+''
	 end
	 --print (@sql)
	 exec(@sql+'  ORDER BY P.date DESC')
go 

exec PROC_Select_PoPut_Query '','2018-12-12','',''

select P.ordernumber,P.date,E.Name AS EntrepotName,R.Name AS ReservoirName,U.UserName,P.money,P.state from Poput as P,Entrepot as E,Reservoir as R ,Usertable AS U WHERE P.EntrepotID =E.ID AND P.ReservoirID=R.ID AND P.UserID=U.ID


use ERP
go
if exists(select name from sysobjects where name='PROC_Select_RepertoryStatus' and type='p')
drop procedure PROC_Select_RepertoryStatus
go
create procedure PROC_Select_RepertoryStatus
@EntrepotID int,
@ReservoirID int
AS
SELECT   dbo.Commodity.Name as CommodityName, dbo.Repertory.CommidityID, dbo.Commodity.Maximum, dbo.Commodity.Minimum, 
                dbo.Commodity.Cost, dbo.Entrepot.Name AS EntrepotName, dbo.Reservoir.Name AS ReservoirName, sum(dbo.Repertory.numb) as existing

FROM      dbo.Commodity INNER JOIN
                dbo.Entrepot ON dbo.Commodity.ID = dbo.Entrepot.ID INNER JOIN
                dbo.Repertory ON dbo.Commodity.ID = dbo.Repertory.CommidityID AND 
                dbo.Entrepot.ID = dbo.Repertory.EntrepotID INNER JOIN
                dbo.Reservoir ON dbo.Entrepot.ID = dbo.Reservoir.EntrepotID AND dbo.Repertory.ReservoirID = dbo.Reservoir.ID 
				where dbo.Repertory.EntrepotID=@EntrepotID and dbo.Repertory.ReservoirID=@ReservoirID
				group by dbo.Commodity.Name, dbo.Repertory.CommidityID,dbo.Commodity.Maximum,Commodity.Minimum, dbo.Commodity.Cost, dbo.Entrepot.Name,dbo.Reservoir.Name


EXEC PROC_Select_RepertoryStatus 1,1;



use ERP
go
if exists(select name from sysobjects where name='PROC_Select_User' and type='p')
drop procedure PROC_Select_RepertoryStatus
go
create procedure PROC_Select_User
@UserName nvarchar(50),
@Passworld nvarchar(50)
AS
SELECT   dbo.Usertable.ID, dbo.Class.Name as ClassName, dbo.Usertable.RealName, dbo.Usertable.Tel, dbo.Usertable.Sex, dbo.Usertable.QQ, 
                dbo.Usertable.State, dbo.Usertable.ClassID
FROM      dbo.Class INNER JOIN
                dbo.Usertable ON dbo.Class.ID = dbo.Usertable.ClassID WHERE dbo.Usertable.UserName =@UserName and dbo.Usertable.Passworld = @Passworld

exec PROC_Select_User 'admin','admin'