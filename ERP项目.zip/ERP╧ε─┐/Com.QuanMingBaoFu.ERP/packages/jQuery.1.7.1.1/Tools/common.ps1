/> class.
            </summary>
            <param name="internalContext">The internal context.</param>
            <param name="type">The type.</param>
            <param name="dataRecord">The data record.</param>
            <param name="isEntityValues">If set to <c>true</c> this is a dictionary for an entity, otherwise it is a dictionary for a complex object.</param>
        </member>
        <member name="M:System.Data.Entity.Internal.DbDataRecordPropertyValues.GetItemImpl(System.String)">
            <summary>
                Gets the dictionary item for a given property name.
            </summary>
            <param name = "propertyName">Name of the property.</param>
            <returns>An item for the given name.</returns>
        </member>
        <member name="P:System.Data.Entity.Internal.DbDataRecordPropertyValues.PropertyNames">
            <summary>
                Gets the set of names of all properties in this dictionary as a read-only set.
            </summary>
            <value>The property names.</value>
        </member>
        <member name="T:System.Data.Entity.Internal.DbDataRecordPropertyValuesItem">
            <summary>
                An implementation of <see cref="T:System.Data.Entity.Internal.IPropertyValuesItem"/> for an item in a <see cref="T:System.Data.Entity.Internal.DbDataRecordPropertyValues"/>.
            </summary>
        </member>
        <member name="M:System.Data.Entity.Internal.DbDataRecordPropertyValuesItem.#ctor(System.Data.Objects.DbUpdatableDataRecord,System.Int32,System.Object)">
            <summary>
                Initializes a new instance of the <see cref="T:System.Data.Entity.Internal.DbDataRecordPropertyValuesItem"/> class.
            </summary>
            <param name="dataRecord">The data record.</param>
            <param name="ordinal">The ordinal.</param>
            <param name="value">The value.</param>
        </member>
        <member name="P:System.Data.Entity.Internal.DbDataRecordPropertyValuesItem.Value">
            <summary>
                Gets or sets the value of the property represented by this item.
            </summary>
            <value>The value.</value>
        </member>
        <member name="P:System.Data.Entity.Internal.DbDataRecordPropertyValuesItem.Name">
            <summary>
                Gets the name of the property.
            </summary>
            <value>The name.</value>
        </member>
        <member name="P:System.Data.Entity.Internal.DbDataRecordPropertyValuesItem.IsComplex">
            <summary>
                Gets a value indicating whether this item represents a complex property.
            </summary>
            <value>
                <c>true</c> If this instance represents a complex property; otherwise, <c>false</c>.
            </value>
        </member>
        <member name="P:System.Data.Entity.Internal.DbDataRecordPropertyValuesItem.Type">
            <summary>
                Gets the type of the underlying property.
            </summary>
            <value>The property type.</value>
        </member>
        <member name="T:System.Data.Entity.Internal.IEntityStateEntry">
            <summary>
                This is version of an internal interface that already exists in System.Data.Entity that
                is implemented by <see cref="T:System.Data.Objects.ObjectStateEntry"/>.  Using this interface allows state
                entries to be mocked for unit testing.  The plan is to remove this version of the
                interface and use the one in System.Data.Entity once we roll into the framework.
                Note that some members may need to be added to the interface in the framework when
                we combine the two.
            </summary>
        </member>
        <member name="T:System.Data.Entity.Internal.InternalCollectionEntry">
            <summary>
                The internal class used to implement <see c