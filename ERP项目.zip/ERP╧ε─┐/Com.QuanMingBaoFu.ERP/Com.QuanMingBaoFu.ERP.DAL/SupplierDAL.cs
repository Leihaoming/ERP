﻿using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.DAL
{
     public class SupplierDAL
    {
         public List<SupplierModel> QueryAll() {
             string sql = "select * from Supplier";
             List<SupplierModel> list = new List<SupplierModel>();
             DataTable dt = DBHelper.Instance().GetDataTableBySql(sql);
             if (dt == null)
             {
                 return null;
             }
             else { 
                foreach(DataRow dr in dt.Rows){
                    SupplierModel model = new SupplierModel();
                    model.ID = int.Parse(dr["ID"].ToString());
                    model.VendorName = dr["VendorName"].ToString();
                    model.Region = dr["Region"].ToString();
                    model.postcode = dr["postcode"].ToString();
                    model.Address = dr["Address"].ToString();
                    model.Contact = dr["Contact"].ToString();
                    model.Tel = dr["Tel"].ToString();
                    model.url = dr["url"].ToString();
                    model.Email = dr["Email"].ToString();
                    model.nashuihao = dr["nashuihao"].ToString();
                    model.state = dr["state"].ToString();
                    model.Remark = dr["Remark"].ToString();
                    list.Add(model);
                }
                return list;
             }
         }

         public bool Add(SupplierModel model) {

             string sql = string.Format("insert into Supplier values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}')",model.VendorName,model.Region,model.postcode,model.Address,model.Contact,model.Tel,model.url,model.Email,model.nashuihao,model.state,model.Remark);
             bool result = DBHelper.Instance().ExcuteSql(sql);
             return result;
         }
    }
}
