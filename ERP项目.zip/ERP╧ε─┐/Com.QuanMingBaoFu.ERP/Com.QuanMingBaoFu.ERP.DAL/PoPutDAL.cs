﻿using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.DAL
{
    public class PoPutDAL
    {
        //通过ordernumber获取订单信息
        public static PoPutModel getordernumber(string ordernumber)
        {

            DataTable dt = DBHelper.Instance().GetDataTableByProcedure("PROC_SELECT_PoPut_BY_OrderNumber", new SqlParameter[] { new SqlParameter("@ordernumber", ordernumber) });
            if (dt == null)
            {
                return null;
            }
            DataRow dr = dt.Rows[0];
            PoPutModel model = new PoPutModel();
            model.ordernumber = dr["ordernumber"].ToString();
            model.date = Convert.ToDateTime(dr["date"].ToString()).ToString("yyyy-MM-dd");
            model.UserName = dr["UserName"].ToString();
            model.EntrepotName = dr["EntrepotName"].ToString();
            model.ReservoirName = dr["ReservoirName"].ToString();
            model.money = double.Parse(dr["money"].ToString());
            model.state = dr["state"].ToString();
            model.rktime = Convert.ToDateTime(dr["rktime"].ToString()).ToString("yyyy-MM-dd");
            model.remark = dr["remark"].ToString();

            return model;

        }

        //添加入库订单（存储过程）
        public static bool Add(PoPutModel model)
        {

            return DBHelper.Instance().ExcuteProcedure("PROC_Add_PoPut", new SqlParameter[] {
                new SqlParameter("@ordernumber", model.ordernumber),
                new SqlParameter("@UserID", model.UserID),
                new SqlParameter("@date",model.date),
                new SqlParameter("@Ponumber",model.Ponumber),
                new SqlParameter("@rktime",model.rktime),
                new SqlParameter("@EntrepotID",model.EntrepotID),
                new SqlParameter("@ReservoirID",model.ReservoirID),
                new SqlParameter("@money",model.money),
                new SqlParameter("@yfmoney",model.yfmoney),
                new SqlParameter("@type",model.type),
                new SqlParameter("@state",model.state),
                new SqlParameter("@remark",model.remark)
            });

        }

        //复杂查询
        public static List<PoPutModel> ManagePageSelect(string ordernumber, string starttime, string endtime, string state)
        {
            //解决存储过程语句拼接问题
            if (starttime != "") {
                starttime = "'" + starttime + "'";
            }
            if (endtime != "") {
                endtime = "'" + endtime + "'";
            }
            if (ordernumber != "") {
                ordernumber = "'" + ordernumber + "'";
            }
            if (state != "") {
                state = "'" + state + "'";
            }

            //获取数据
            DataTable dt = DBHelper.Instance().GetDataTableByProcedure("PROC_Select_PoPut_Query", new SqlParameter[] { 
                new SqlParameter("@ordernumber",ordernumber),
                 new SqlParameter("@starttime",starttime),
                  new SqlParameter("@endtime",endtime),
                   new SqlParameter("@state",state)
            });

            if (dt == null)
            {
                return null;
            }
            List<PoPutModel> list = new List<PoPutModel>();
            foreach (DataRow dr in dt.Rows) {
                PoPutModel model = new PoPutModel();
                model.ordernumber = dr["ordernumber"].ToString();
                model.date = Convert.ToDateTime(dr["date"].ToString()).ToString("yyyy-MM-dd");
                model.EntrepotName = dr["EntrepotName"].ToString();
                model.ReservoirName = dr["ReservoirName"].ToString();
                model.UserName = dr["UserName"].ToString();
                model.money = double.Parse(dr["money"].ToString());
                model.state = dr["state"].ToString();
                list.Add(model);
            }
            return list;
        }

        //根据订单号删除
        public static bool DeleteByOrdernumber(string ordernumber) {
            string sql1 = string.Format("delete from Poputdetails where ordernumber = '{0}'", ordernumber);
            string sql2 = string.Format("delete from Poput where ordernumber = '{0}'", ordernumber);
            if (DBHelper.Instance().ExcuteSql(sql1))
            {
                bool result = DBHelper.Instance().ExcuteSql(sql2);
                return result;
            }
            else {
                return false;
            }
                    
        }

        //审核方法
        public static bool PoPutAudit(string table, string ordernumber,string state)
        { 
            return DBHelper.Instance().ExcuteProcedure("PROC_Update_Po_State",new SqlParameter[]{
                new SqlParameter("@table",table),
                new SqlParameter("@ordernumber",ordernumber),
                new SqlParameter("@state",state)
            });
        }


    }
}
