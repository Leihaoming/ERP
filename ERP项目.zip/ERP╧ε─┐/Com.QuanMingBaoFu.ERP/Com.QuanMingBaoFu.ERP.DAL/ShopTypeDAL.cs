﻿using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.DAL
{
    public class ShopTypeDAL
    {
        public List<ShopTypeModel> QueryALL() {
            string sql = "select * from GoodsType";
            DataTable dt = DBHelper.Instance().GetDataTableBySql(sql);
            List<ShopTypeModel> list = new List<ShopTypeModel>();
            if (dt == null)
            {
                return null;
            }
            else { 
                foreach(DataRow dr in dt.Rows){
                    ShopTypeModel model = new ShopTypeModel();
                    model.ID = int.Parse(dr["ID"].ToString());
                    model.Name = dr["Name"].ToString();
                    model.Describe = dr["Describe"].ToString();
                    model.state = dr["state"].ToString();
                    list.Add(model);
                }
                return list;
            }
        }

        public bool Add(ShopTypeModel model)
        {
            string sql = string.Format("insert into GoodsType values('{0}','{1}','{2}')",model.Name,model.Describe,model.state);
            bool result = DBHelper.Instance().ExcuteSql(sql);
            return result;
        }
    }
}
