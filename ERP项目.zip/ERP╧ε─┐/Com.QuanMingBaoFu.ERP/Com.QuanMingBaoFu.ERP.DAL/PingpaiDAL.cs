﻿using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.DAL
{
    public class PingpaiDAL
    {
        public List<PingpaiModel> QueryALL() {
            string sql = "select * from Brand";
            DataTable dt = DBHelper.Instance().GetDataTableBySql(sql);
            List<PingpaiModel> list = new List<PingpaiModel>();
            if (dt == null)
            {
                return null;
            }
            else { 
                foreach(DataRow dr in dt.Rows){
                    PingpaiModel model = new PingpaiModel();
                    model.ID = int.Parse(dr["ID"].ToString());
                    model.Name = dr["Name"].ToString();
                    model.Describe = dr["Describe"].ToString();
                    model.state = dr["state"].ToString();
                    list.Add(model);
                }
                return list;
            }
        }

        public bool Add(PingpaiModel model) {
            string sql = string.Format("insert into Brand values('{0}','{1}','{2}')",model.Name,model.Describe,model.state);
            bool result = DBHelper.Instance().ExcuteSql(sql);
            return result;
        }
    }
}
