﻿using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.DAL
{
    public class RepertoryDAL
    {
        /// <summary>
        /// 添加库存方法
        /// </summary>
        /// <param name="ordernumber">入库单号</param>
        /// <param name="remark">库存单商品备注信息</param>
        public void AddRepertory(string ordernumber, string remark="")
        {
            string sql = string.Format("select Poput.EntrepotID,Poput.ReservoirID,Poputdetails.Numble as numb,Poputdetails.CommidityID from Poput,Poputdetails where Poput.ordernumber=Poputdetails.ordernumber and poput.ordernumber = '{0}'", ordernumber);
            DataTable dt = DBHelper.Instance().GetDataTableBySql(sql);
            if (dt == null) {
                return;
            };
            //循环查询入库订单相关信息，并添加至入库单
            foreach(DataRow dr in dt.Rows){
                RepertoryModel model = new RepertoryModel();
                model.EntrepotID = int.Parse(dr["EntrepotID"].ToString());
                model.ReservoirID = int.Parse(dr["ReservoirID"].ToString());
                model.numb = int.Parse(dr["numb"].ToString());
                model.Remark = remark;
                model.CommidityID = int.Parse(dr["CommidityID"].ToString());
                DBHelper.Instance().ExcuteSql(string.Format("insert into Repertory(EntrepotID,ReservoirID,CommidityID,numb,Remark) values({0},{1},{2},{3},'{4}')", model.EntrepotID, model.ReservoirID, model.CommidityID, model.numb, model.Remark));
            }
        }
    }
}
