﻿using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.DAL
{
    public class PoPutDetailsDAL
    {
        //根据ordernumber获取入库订单详情
        public static List<PoPutDetailsModel> getOrderNumber(string ordernumber)
        {
            DataTable dt = DBHelper.Instance().GetDataTableByProcedure("PROC_SELECT_PoPutDetails_BY_OrderNumber", new SqlParameter[]{ new SqlParameter("@ordernumber", ordernumber)});
            List<PoPutDetailsModel> list = new List<PoPutDetailsModel>();
            if (dt == null) {
                return null;
            }
            foreach (DataRow dr in dt.Rows)
            {
                PoPutDetailsModel model = new PoPutDetailsModel();

                model.Numble = int.Parse(dr["Numble"].ToString()); //数量
                model.money = double.Parse(dr["money"].ToString()); //金额
                model.taxrate = double.Parse(dr["taxrate"].ToString()); //税率
                model.price = double.Parse(dr["price"].ToString()); //采购额
                model.CommidityID = int.Parse(dr["CommidityID"].ToString());//商品编号
                model.discountrate = double.Parse(dr["discountrate"].ToString()); //折扣
                model.Name = dr["Name"].ToString();//商品名
                model.VendorName = dr["VendorName"].ToString();//供应商名字

                list.Add(model);

            }

            return list;
        }

        //添加入库详情
        public static bool Add(PoPutDetailsModel model) {

            return DBHelper.Instance().ExcuteProcedure("PROC_Add_PoPutDetails",new SqlParameter[]{
                new SqlParameter("@ordernumber",model.ordernumber),
                new SqlParameter("@CommidityID",model.CommidityID),
                new SqlParameter("@Numble",model.Numble),
                new SqlParameter("@taxrate",model.taxrate),
                new SqlParameter("@discountrate",model.discountrate),
                new SqlParameter("@SupplierID",model.SupplierID),
                new SqlParameter("@price",model.price),
                new SqlParameter("@money",model.money),
                new SqlParameter("@describe",model.describe),
            });

        }
    }
}
