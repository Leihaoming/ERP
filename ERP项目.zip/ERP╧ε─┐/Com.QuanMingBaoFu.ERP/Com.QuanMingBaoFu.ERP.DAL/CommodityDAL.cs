﻿using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.DAL
{
    public class CommodityDAL
    {
        //查询商品基本信息
        public List<CommodityModel> QueryAll() {
            List<CommodityModel> list = new List<CommodityModel>();
            string sql = "select * from Commodity";
            DataTable dt = DBHelper.Instance().GetDataTableBySql(sql);
            if (dt == null)
            {
                return null;
            }
            else { 
                foreach(DataRow dr in dt.Rows){
                    CommodityModel model = new CommodityModel();
                    model.ID = int.Parse(dr["ID"].ToString());
                    model.Name = dr["Name"].ToString();
                    model.rktime = dr["rktime"].ToString();
                    model.Maximum =int.Parse( dr["Maximum"].ToString());
                    model.Minimum =int.Parse( dr["Minimum"].ToString());
                    model.Cost = double.Parse(dr["Cost"].ToString());
                    list.Add(model);
                }
                return list;
            }
        }

        //添加商品信息
        public bool Add(CommodityModel model) {

            string sql = string.Format("insert into Commodity values('{0}',{1},{2},{3},{4},{5},{6},'{7}','{8}',{9},'{10}','{11}','{12}','{13}','{14}','{15}','{16}','{17}','{18}')",model.Name,model.Maximum,model.Minimum,model.Cost,model.Price,model.BrandID,model.TypeID,model.Color,model.unit,model.Weight,model.Specification,model.picture,model.Texture,model.zhrktime,model.rktime
                ,model.sjtime,model.xjtime,model.qhtime,model.Describe);

            bool result = DBHelper.Instance().ExcuteSql(sql);
            return result;

        }

        //更新图片路径
        public bool UpdatePicture(int id,string url) {

            string sql = string.Format("update Commodity set picture = '{0}' where ID = {1}",url,id);
            bool result = DBHelper.Instance().ExcuteSql(sql);

            return result;

        }
    }
}
