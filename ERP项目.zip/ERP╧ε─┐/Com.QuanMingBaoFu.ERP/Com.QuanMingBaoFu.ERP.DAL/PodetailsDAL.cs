﻿using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.DAL
{
    public class PodetailsDAL
    {
        //新增
        public bool PodetailsAdd(PodetailsModel model)
        {

            string sql = string.Format(@"insert into Podetails values('{0}',{1},{2},{3},{4},{5},{6},{7},'{8}')"
                ,model.ordernumber,model.CommidityID,model.Numble,model.taxrate,model.discountrate,model.SupplierID,
                model.price,model.money,model.describe);

            bool result = DBHelper.Instance().ExcuteSql(sql);

            return result;
        }

        //根据订单号删除相应记录
        public bool PodetailsDelete(string ordernumber)
        {
            string sql = string.Format("DELETE FROM Podetails WHERE ordernumber = '{0}'", ordernumber);
            bool result = DBHelper.Instance().ExcuteSql(sql);
            return result;
        }

        
        //订单详情页，根据单号查详情
        public List<PodetailsModel> getPodetailsModelOrder(string ordernumber)
        {
            string sql = string.Format("select * from View_Podetails_Manages where ordernumber ='{0}'",ordernumber);

            DataTable dt = DBHelper.Instance().GetDataTableBySql(sql);
            List<PodetailsModel> list = new List<PodetailsModel>();
             
            foreach(DataRow dr in dt.Rows){
                PodetailsModel model = new PodetailsModel();
                model.Numble = int.Parse(dr["Numble"].ToString());
                model.money = double.Parse(dr["money"].ToString());
                model.taxrate = double.Parse(dr["taxrate"].ToString());
                model.price = double.Parse(dr["price"].ToString());
                model.CommidityID = int.Parse(dr["CommidityID"].ToString());
                model.discountrate = double.Parse(dr["discountrate"].ToString());
                model.Name = dr["Name"].ToString();
                model.VendorName = dr["VendorName"].ToString();
                model.ordernumber = dr["ordernumber"].ToString();
                model.SupplierID = int.Parse(dr["SupplierID"].ToString());
                model.describe = dr["describe"].ToString();
                list.Add(model);
            }

            return list;
        }
    }
}
