﻿using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.DAL
{
    public class PODAL
    {
        //添加订单方法
        public bool POAdd(POModel model)
        {

            string sql = string.Format("insert into Po values('{0}','{1}',{2},'{3}','{4}','{5}',{6},{7},{8},'{9}','{10}','{11}')", model.ordernumber, model.UserName, model.UserID, model.time, model.qdtime, model.jhtime, model.EntrepotID, model.ReservoirID, model.money, model.jhaddress, model.Describe, model.state);

            bool result = DBHelper.Instance().ExcuteSql(sql);

            return result;
        }

        //订单管理页订单查询方法

        public List<PoMangeModel> PoManageQuery(int currentPage, int PageSize, string ordernumber, string starttime, string endtime, string state)
        {

            string sql = string.Format("select top {0} * from view_po_manage where ordernumber not in(select top (({1}-1)*{2}) ordernumber from  view_po_manage)", PageSize, currentPage, PageSize);

            if (ordernumber != "")
            {
                sql += string.Format("and ordernumber like '%{0}%'", ordernumber);
            }
            if (starttime != "" && endtime == "")
            {
                sql += string.Format("and time > '{0}'", starttime);
            }
            if (starttime == "" && endtime != "")
            {
                sql += string.Format("and time < '{0}'", endtime);
            }
            if (starttime != "" && endtime != "")
            {
                sql += string.Format("and time BETWEEN '{0}' AND '{1}'", starttime, endtime);
            }
            if (state != "")
            {
                sql += string.Format("and state = '{0}'", state);
            }

            List<PoMangeModel> list = new List<PoMangeModel>();

            DataTable dt = DBHelper.Instance().GetDataTableBySql(sql);
            if (dt != null)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    PoMangeModel model = new PoMangeModel();
                    model.ordernumber = dr["ordernumber"].ToString();
                    model.SalesMan = dr["SalesMan"].ToString();
                    model.ReservoirName = dr["ReservoirName"].ToString();
                    model.EntrepotName = dr["EntrepotName"].ToString();
                    model.ZDRName = dr["ZDRName"].ToString();
                    model.time = Convert.ToDateTime(dr["time"].ToString()).ToString("yyyy-MM-dd hh:mm:ss");
                    model.state = dr["state"].ToString();
                    model.money = double.Parse(dr["money"].ToString());

                    list.Add(model);

                }

            }

            return list;
        }

        //查询总记录数
        public int PoNumb(string ordernumber, string starttime, string endtime, string state)
        {

            string sql = "select * from view_po_manage where 1=1";

            if (ordernumber != "")
            {
                sql += string.Format("and ordernumber like '%{0}%'", ordernumber);
            }
            if (starttime != "" && endtime == "")
            {
                sql += string.Format("and time > '{0}'", starttime);
            }
            if (starttime == "" && endtime != "")
            {
                sql += string.Format("and time < '{0}'", endtime);
            }
            if (starttime != "" && endtime != "")
            {
                sql += string.Format("and time BETWEEN '{0}' AND '{1}'", starttime, endtime);
            }
            if (state != "")
            {
                sql += string.Format("and state = '{0}'", state);
            }

            DataTable dt = DBHelper.Instance().GetDataTableBySql(sql);

            int numb = dt.Rows.Count;

            return numb;
        }

        //根据订单号删除相应记录
        public bool PoDelete(string ordernumber)
        {

            string sql = string.Format("DELETE FROM Po WHERE ordernumber = '{0}'", ordernumber);
            bool result = DBHelper.Instance().ExcuteSql(sql);
            return result;
        }

        //审核方法，更新状态为已审
        public bool AuditMethods(string ordernumber)
        {
            string sql = string.Format("UPDATE Po SET state='y' WHERE ordernumber = '{0}'", ordernumber);
            bool result = DBHelper.Instance().ExcuteSql(sql);
            return result;

        }

        //反审方法，将状态倒置
        public bool reverseMethods(string ordernumber)
        {
            string sql = string.Format("SELECT state FROM Po WHERE ordernumber = '{0}'", ordernumber);
            string sql2 = "";
            DataTable dt = DBHelper.Instance().GetDataTableBySql(sql);
            string state = dt.Rows[0]["state"].ToString();
            if (state.Trim() == "n")
            {
                sql2 = string.Format("UPDATE Po SET state='{0}' WHERE ordernumber = '{1}'", "y", ordernumber);
            }
            else
            {
                sql2 = string.Format("UPDATE Po SET state='{0}' WHERE ordernumber = '{1}'", "n", ordernumber);
            }
            bool result = DBHelper.Instance().ExcuteSql(sql2);
            return result;

        }

        //订单详情页，根据单号查询
        public PoMangeModel getPoModelOrder(string ordernumber)
        {
            string sql = string.Format("SELECT * FROM view_po_manage WHERE ordernumber = '{0}'", ordernumber);
            DataTable dt = DBHelper.Instance().GetDataTableBySql(sql);
            PoMangeModel model = new PoMangeModel();
            model.ordernumber = dt.Rows[0]["ordernumber"].ToString();
            model.SalesMan = dt.Rows[0]["SalesMan"].ToString();
            model.ReservoirName = dt.Rows[0]["ReservoirName"].ToString();
            model.EntrepotName = dt.Rows[0]["EntrepotName"].ToString();
            model.ZDRName = dt.Rows[0]["ZDRName"].ToString();
            model.time = Convert.ToDateTime(dt.Rows[0]["time"].ToString()).ToString("yyyy-MM-dd hh:mm:ss");
            model.state = dt.Rows[0]["state"].ToString();
            model.jhaddress = dt.Rows[0]["jhaddress"].ToString();
            model.Describe = dt.Rows[0]["Describe"].ToString();
            model.jhtime = Convert.ToDateTime(dt.Rows[0]["jhtime"].ToString()).ToString("yyyy-MM-dd hh:mm:ss");
            model.qdtime = Convert.ToDateTime(dt.Rows[0]["qdtime"].ToString()).ToString("yyyy-MM-dd hh:mm:ss");

            return model;
        }

        //采购入库页，根据单号查库房、库区、总额
        public static POModel getPoModel(string ordernumber) {
            string sql = string.Format("SELECT * FROM Po WHERE ordernumber = '{0}'", ordernumber);
            DataTable dt = DBHelper.Instance().GetDataTableBySql(sql);
            POModel model = new POModel();
            model.EntrepotID = int.Parse(dt.Rows[0]["EntrepotID"].ToString());
            model.ReservoirID =int.Parse(dt.Rows[0]["ReservoirID"].ToString());
            model.money = double.Parse( dt.Rows[0]["money"].ToString());
            return model;
        }

        //查询指定时间段订单信息
        public static List<PoMangeModel> getPotime(string starttime, string endtime, string state)
        {

            string sql = "select * from view_po_manage where 1=1";

            if (starttime != "" && endtime == "")
            {
                sql += string.Format("and time > '{0}'", starttime);
            }
            if (starttime == "" && endtime != "")
            {
                sql += string.Format("and time < '{0}'", endtime);
            }
            if (starttime != "" && endtime != "")
            {
                sql += string.Format("and time BETWEEN '{0}' AND '{1}'", starttime, endtime);
            }
            if (state != "")
            {
                sql += string.Format("and state = '{0}'", state);
            }

            List<PoMangeModel> list = new List<PoMangeModel>();

            DataTable dt = DBHelper.Instance().GetDataTableBySql(sql);
            if (dt != null)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    PoMangeModel model = new PoMangeModel();
                    model.ordernumber = dr["ordernumber"].ToString();
                    model.SalesMan = dr["SalesMan"].ToString();
                    model.ReservoirName = dr["ReservoirName"].ToString();
                    model.EntrepotName = dr["EntrepotName"].ToString();
                    model.time = Convert.ToDateTime(dr["time"].ToString()).ToString("yyyy-MM-dd hh:mm:ss");
                    model.state = dr["state"].ToString();
                    model.money = double.Parse(dr["money"].ToString());

                    list.Add(model);
                }
            }
            return list;

        }

        //修改订单状态（存储过程）
        public static bool UpdateState(string table,string ordernumber,string state){

            return DBHelper.Instance().ExcuteProcedure("PROC_Update_Po_State", new SqlParameter[] { new SqlParameter("@table", table), new SqlParameter("@ordernumber", ordernumber), new SqlParameter("@state", state) });
            
        }


    }
}
