﻿using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Com.QuanMingBaoFu.ERP.DAL
{
    public class RepertoryStatusDAL
    {
        /// <summary>
        /// 获取详情
        /// </summary>
        /// <param name="EntrepotID">库房ID</param>
        /// <param name="ReservoirID">库区ID</param>
        /// <returns>List<RepertoryStatusModel></RepertoryStatusModel></returns>
        public List<RepertoryStatusModel> SelectRepertory(int EntrepotID, int ReservoirID)
        {
            DataTable dt = DBHelper.Instance().GetDataTableByProcedure("PROC_Select_RepertoryStatus", new SqlParameter[]{
               new SqlParameter("@EntrepotID",EntrepotID),
               new SqlParameter("@ReservoirID",ReservoirID)
            });
            if (dt == null) {
                return null;
            }
            List<RepertoryStatusModel> list = new List<RepertoryStatusModel>();
            foreach (DataRow dr in dt.Rows) {
                RepertoryStatusModel model = new RepertoryStatusModel();
                model.CommidityID = int.Parse(dr["CommidityID"].ToString());
                model.Maximum = int.Parse(dr["Maximum"].ToString());
                model.Minimum = int.Parse(dr["Minimum"].ToString());
                model.Cost = int.Parse(dr["Cost"].ToString());
                model.existing = int.Parse(dr["existing"].ToString());
                model.EntrepotName = dr["EntrepotName"].ToString();
                model.ReservoirName = dr["ReservoirName"].ToString();
                model.CommodityName = dr["CommodityName"].ToString();
                list.Add(model);
            }
            return list;
        }
    }
}
