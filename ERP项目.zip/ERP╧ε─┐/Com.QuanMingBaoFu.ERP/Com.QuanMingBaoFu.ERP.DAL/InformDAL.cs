﻿using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.DAL
{
    public class InformDAL
    {
        //添加通知
        public bool Add(InformModel Inform) {
            string sql = string.Format("insert into inform(Title,Details,Type,UserID) VALUES('{0}','{1}',{2},{3})",Inform.Title, Inform.Details, Inform.Type, 2);
            return DBHelper.Instance().ExcuteSql(sql);
        }

        public List<InformModel> QueryAll() {
            string sql = string.Format("select a.* ,b.UserName from inform a ,Usertable b where a.UserID = b.ID");
            DataTable dt = DBHelper.Instance().GetDataTableBySql(sql);
            List<InformModel> list = new List<InformModel>();
            foreach (DataRow dr in dt.Rows) { 
                InformModel model = new InformModel();
                model.ID = int.Parse(dr["ID"].ToString());
                model.Title = dr["Title"].ToString();
                model.Details = dr["Details"].ToString();
                model.Time = dr["Time"].ToString();
                model.UserID = int.Parse(dr["UserID"].ToString());
                model.Type = int.Parse(dr["Type"].ToString());
                model.UserName = dr["UserName"].ToString();
                list.Add(model);
            }
     
            return list;
        }
    }
}
