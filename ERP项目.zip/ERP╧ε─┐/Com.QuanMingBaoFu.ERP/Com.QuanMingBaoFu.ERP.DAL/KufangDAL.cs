﻿using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.DAL
{
    public class KufangDAL
    {
        public bool KufangAdd(string Name, string describe)
        {
            string sql = string.Format("INSERT INTO Entrepot VALUES('{0}','{1}')",Name,describe);
            return DBHelper.Instance().ExcuteSql(sql);
        }

        public List<KufangModel> QueryAll() {
            string sql = "select * from Entrepot";
            DataTable dt = DBHelper.Instance().GetDataTableBySql(sql);
            List<KufangModel> list = new List<KufangModel>();
            if (dt != null) {
                foreach (DataRow dr in dt.Rows) {
                    KufangModel model = new KufangModel();
                    model.ID = int.Parse(dr["ID"].ToString());
                    model.Name = dr["Name"].ToString();
                    model.describe = dr["describe"].ToString();
                    list.Add(model);
                }
                return list;
            }
            else{
                return null;
            }
        }
    }
}
