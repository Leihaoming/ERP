﻿using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.DAL
{
     public class UserDAL
    {
        //根据用户名，密码查询用户将
        public UserModel QueryUser(string User,string pwd) {
            string sql = string.Format("select * from Usertable where UserName='{0}' and Passworld='{1}'",User,pwd);
            DataTable dt = DBHelper.Instance().GetDataTableBySql(sql);
            UserModel model = new UserModel();
           if (dt != null&&dt.Rows.Count >0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    model.ID = int.Parse(dr["ID"].ToString());
                    model.RealName = dr["RealName"].ToString();
                    model.Sex = dr["Sex"].ToString();
                    model.State = dr["State"].ToString();
                    model.Passworld = dr["Passworld"].ToString();
                    model.Tel = dr["Tel"].ToString();
                    model.ClassID = int.Parse(dr["ClassID"].ToString());
                    model.QQ = dr["QQ"].ToString();
                    model.UserName = dr["UserName"].ToString();
                }
                return model;
            }
            else {
                return null;
            }
        }
    }
}
