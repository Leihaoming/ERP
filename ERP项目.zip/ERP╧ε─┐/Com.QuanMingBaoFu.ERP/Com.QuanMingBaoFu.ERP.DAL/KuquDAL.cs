﻿using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.DAL
{
    public class KuquDAL
    {
        public List<KuquModel> QueryAll() {
            string sql = "select a.Name as EntrepotName, B.* from Entrepot A ,Reservoir B where a.ID = b.EntrepotID";
            DataTable dt = DBHelper.Instance().GetDataTableBySql(sql);
            List<KuquModel> list = new List<KuquModel>();
            if (dt == null)
            {
                return null;
            }
            else {
                foreach (DataRow dr in dt.Rows) { 
                     KuquModel model = new KuquModel();
                     model.ID = int.Parse(dr["ID"].ToString());
                     model.Name = dr["Name"].ToString();
                     model.state = dr["state"].ToString();
                     model.Describe = dr["Describe"].ToString();
                     model.EntrepotName = dr["EntrepotName"].ToString();
                     model.EntrepotID = int.Parse(dr["EntrepotID"].ToString());
                     list.Add(model);
                }
                return list;
            }
        }

        public List<KuquModel> QeryKufangID(int id) {
            string sql = string.Format("select * from Reservoir where EntrepotID = {0} and state = 'y' ",id);
            DataTable dt = DBHelper.Instance().GetDataTableBySql(sql);
            List<KuquModel> list = new List<KuquModel>();
            if (dt == null)
            {
                return null;
            }
            else {
                foreach (DataRow dr in dt.Rows) {
                    KuquModel model = new KuquModel();
                    model.ID = int.Parse(dr["ID"].ToString());
                    model.Name = dr["Name"].ToString();
                    model.state = dr["state"].ToString();
                    model.Describe = dr["Describe"].ToString();
                    model.EntrepotID = int.Parse(dr["EntrepotID"].ToString());
                    list.Add(model);
                }
                return list;
            }
        }

        //库区添加
        public static bool AddSave(KuquModel model) {

            string sql = string.Format("insert into Reservoir values('{0}',{1},'{2}','{3}')",model.Name,model.EntrepotID,model.Describe,model.state);

            bool result = DBHelper.Instance().ExcuteSql(sql);

            return result;
        }
    }
}
