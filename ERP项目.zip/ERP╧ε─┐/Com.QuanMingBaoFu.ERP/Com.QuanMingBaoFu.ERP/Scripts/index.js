$(function(){
	$(".classtitle").click(function(){
		$(this).siblings("ul").toggle();
	})
})