﻿using Com.QuanMingBaoFu.ERP.BLL;
using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Com.QuanMingBaoFu.ERP.Controllers
{
    public class StockControlController : Controller
    {
        //
        // GET: /StockControl/
        KufangBLL kfbll = new KufangBLL();
        KuquBLL kqbll = new KuquBLL();
        RepertoryStatusBLL repertorystatusbll = new RepertoryStatusBLL();

        //库存情况页面，初始化
        public ActionResult RepertoryStatus()
        {
            //获取所有库房
            List<KufangModel> kufanglist = kfbll.QueryAll();
            //获取所有库区
            List<KuquModel> kuqulist = kqbll.QueryAll();
            Hashtable model = new Hashtable();
            model.Add("kufanglist",kufanglist);
            model.Add("kuqulist",kuqulist);

            return View(model);
        }

        /// <summary>
        /// Ajax查询相应库存
        /// </summary>
        /// <param name="EntrepotID">库房ID</param>
        /// <param name="ReservoirID">库区ID</param>
        /// <returns>json</returns>
        public ActionResult SelectRepertory(int EntrepotID,int ReservoirID)
        {
            List<RepertoryStatusModel> list = repertorystatusbll.SelectRepertory(EntrepotID,ReservoirID);
            return Json(list,JsonRequestBehavior.AllowGet);           
        }

    }
}
