﻿using Com.QuanMingBaoFu.ERP.DAL;
using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Com.QuanMingBaoFu.ERP.Controllers
{
    public class HomeController : Controller
    {
        UserBLL bll = new UserBLL();
        //
        // GET: /ERP/

        //登陆页
        public ActionResult Index()
        {

            return View();
        }

        //验证登陆
        [HttpPost]
        public ActionResult Index(string username, string pwd)
        {
            UserModel model = bll.QueryUser(username, pwd);
            if (model != null && model.State != "n")
            {
                Session["usermodel"] = model;
                return RedirectToAction("Homepage", "Home");
            }
            else
            {
                ViewBag.js = "<script>alert('登录失败！');</script>";
                return View();
            }

        }

        //主页
        public ActionResult Homepage()
        {
            if (Session["usermodel"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        //退出
        public ActionResult Quit()
        {
            Session["usermodel"] = null;
            return RedirectToAction("Index");
        }

    }
}
