﻿using Com.QuanMingBaoFu.ERP.DAL;
using Com.QuanMingBaoFu.ERP.DLL;
using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Com.QuanMingBaoFu.ERP.Controllers
{
    public class InformController : Controller
    {
        public InformBLL bll = new InformBLL();
        //
        // GET: /Inform/

        //通知管理页面
        public ActionResult Index()
        {
            if (Session["usermodel"] != null)
            {
                List<InformModel> list = bll.QueryAll();
                return View(list);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        //发送通知页面
        public ActionResult SendInform()
        {
            if (Session["usermodel"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        //添加通知方法
        public ActionResult add(InformModel Inform)
        {
            if (Session["usermodel"] != null)
            {
                bool result = bll.Add(Inform);
                return RedirectToAction("index");
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }

        }

        //通知详情页
        public ActionResult InformContent(int ID)
        {
            if (Session["usermodel"] != null)
            {
                List<InformModel> list = bll.QueryAll();
                InformModel model = null;
                foreach (InformModel item in list)
                {
                    if (item.ID == ID)
                    {
                        model = item;
                    }
                }
                return View(model);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }

        }
    }
}
