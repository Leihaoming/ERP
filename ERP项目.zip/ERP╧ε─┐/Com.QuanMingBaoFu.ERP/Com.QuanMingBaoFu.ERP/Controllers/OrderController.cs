﻿using Com.QuanMingBaoFu.ERP.BLL;
using Com.QuanMingBaoFu.ERP.Model;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Com.QuanMingBaoFu.ERP.Controllers
{
    public class OrderController : Controller
    {
        KufangBLL kufangbll = new KufangBLL();
        KuquBLL kuqubll = new KuquBLL();
        POBLL pobll = new POBLL();
        //
        // GET: /Order/

        public ActionResult PO()
        {
            return View();
        }

        public ActionResult openkuqu()
        {
            List<KufangModel> list = kufangbll.QueryAll();

            return View(list);
        }

        //AJAX请求获取库区
        public ActionResult ajaxkuqu(int id)
        {

            List<KuquModel> list = kuqubll.QeryKufangID(id);

            return Json(list, JsonRequestBehavior.AllowGet);
        }


        //添加订单
        [HttpPost]
        public ActionResult ajaxAdd(string po, string details)
        {
            POModel pomodel = JsonConvert.DeserializeObject<POModel>(po);
            List<PodetailsModel> lists = JsonConvert.DeserializeObject<List<PodetailsModel>>(details);

            int code = 0;
            string message = "订单提交成功";

            try
            {

                UserModel user = Session["usermodel"] as UserModel;
                pomodel.UserID = user.ID;
                POBLL pobll = new POBLL();
                POdetailsBLL podelbll = new POdetailsBLL();
                pobll.POAdd(pomodel);
                foreach (PodetailsModel item in lists)
                {
                    item.ordernumber = pomodel.ordernumber;
                    podelbll.PodetailsAdd(item);
                }
            }
            catch (Exception e)
            {
                code = 1;
                message = e.Message.ToString();

            }


            var obj = new
            {
                code = code,
                message = message
            };

            return Json(obj);
        }


        //订单管理页面
        public ActionResult POMamage()
        {

            return View();
        }

        //订单管理分页，复杂查询,Ajax请求
        public ActionResult POMamageAjax(int currentPage, string ordernumber, string starttime, string endtime, string state, int PageSize = 5)
        {
            PageModel<PoMangeModel> model = pobll.PageQuery(currentPage, PageSize, ordernumber, starttime, endtime, state);

            return Json(model, JsonRequestBehavior.AllowGet);
        }

        //订单删除方法
        public ActionResult POdelete(string[] ordernumberList)
        {

            int code = 0;
            string message = "删除成功！";

            POdetailsBLL pdbll = new POdetailsBLL();

            try
            {
                foreach (string item in ordernumberList)
                {
                    if (pdbll.PodetailsDelete(item))
                    {
                        pobll.PoDelete(item);
                    }
                }
            }
            catch (Exception e)
            {
                code = 1;
                message = "删除失败！(" + e.Message + ")";
            }

            var obj = new
            {
                code = code,
                message = message
            };

            return Json(obj);
        }

        //审核
        public ActionResult auditMethods(string[] ordernumberList)
        {
            int code = 0;
            string message = "审核成功！";

            try
            {
                foreach (string item in ordernumberList)
                {
                    pobll.AuditMethods(item);

                }
            }
            catch (Exception e)
            {
                code = 1;
                message = "审核失败！(" + e.Message + ")";
            }

            var obj = new
            {
                code = code,
                message = message
            };

            return Json(obj);

        }

        //反审
        public ActionResult reverseMethods(string[] ordernumberList)
        {
            int code = 0;
            string message = "反审成功！";

            try
            {
                foreach (string item in ordernumberList)
                {
                    //反审方法
                    pobll.reverseMethods(item);
                }
            }
            catch (Exception e)
            {
                code = 1;
                message = "反审失败！(" + e.Message + ")";
            }

            var obj = new
            {
                code = code,
                message = message
            };

            return Json(obj);

        }

        //采购明细
        public ActionResult Podetails(string ordernumber)
        {

            POdetailsBLL pdbll = new POdetailsBLL();
            PoMangeModel pomodel = pobll.getPoModelOrder(ordernumber);
            List<PodetailsModel> list = pdbll.getPodetailsModelOrder(ordernumber);

            //键值对的形式存储数据
            Hashtable ht = new Hashtable();
            ht.Add("po", pomodel);
            ht.Add("podetails", list);

            return View(ht);
        }


        //采购入库（收货）
        public ActionResult PoWarehousing()
        {

            return View();
        }

        //采购订单选择页面
        public ActionResult openpo(string starttime = "", string endtime = "", string state = "y")
        {
            List<PoMangeModel> list = pobll.getPotime(starttime, endtime, state);
            return View(list);
        }

        //AJAX请求采购订单下详细
        public ActionResult SelectPO(string Ponumber)
        {
            Hashtable list = new Hashtable();
            if (Ponumber != "")
            {
                POModel pomodel = pobll.getPoModel(Ponumber);
                POdetailsBLL pd = new POdetailsBLL();
                List<PodetailsModel> detailsmodel = pd.getPodetailsModelOrder(Ponumber);
                list.Add("pomodel", pomodel);
                list.Add("detailsmodel", detailsmodel);
            }

            return Json(list, JsonRequestBehavior.AllowGet);
        }

        //AJAX提交采购入库单
        //处理数据后重定向到入库订单详情页
        public ActionResult AddPoWarehousing(string poput, string poputdetaile)
        {
            PoPutModel poputmodel = JsonConvert.DeserializeObject<PoPutModel>(poput);
            List<PoPutDetailsModel> lists = JsonConvert.DeserializeObject<List<PoPutDetailsModel>>(poputdetaile);

            int code = 0;
            string message = "订单提交成功！将跳转至详情页~";

            //添加入库订单
            UserModel user = Session["usermodel"] as UserModel;
            poputmodel.UserID = user.ID;
            if (PoPutBLL.Add(poputmodel))
            {
                //循环添加入库详情
                foreach (PoPutDetailsModel item in lists)
                {
                    item.ordernumber = poputmodel.ordernumber;
                    PoPutDetailsBLL.Add(item);
                }
                //修改采购订单状态为已形成入库单
                POBLL.UpdateState("PO", poputmodel.Ponumber, "x");

            }
            else
            {
                code = 1;
                message = "订单提交失败！请稍后再试或联系管理员！";
            }

            var obj = new
            {
                code = code,
                message = message
            };

            return Json(obj);
        }

        //入库订单详情页（入库订单信息，订单详情，采购付款情况）
        public ActionResult PoPutDetails(string ordernumber)
        {
            PoPutModel poputmodel = PoPutBLL.getordernumber(ordernumber); //获取入库订单信息
            List<PoPutDetailsModel> PoPutDetailsList = PoPutDetailsBLL.getOrderNumber(ordernumber); //获取入库订单详情
            //获取该单付款信息 pass
            Hashtable model = new Hashtable(); //声明Hashtable存储数据集合
            model.Add("poputmodel", poputmodel);
            model.Add("PoPutDetailsList", PoPutDetailsList);
            if (poputmodel == null) {
                model = null;
            }
            return View(model);
        }

        //入库订单管理审核页
        public ActionResult PoPutManage()
        {
            return View();
        }
        //入库订单复杂查询
        public ActionResult PoPutManageSelect(string ordernumber, string starttime, string endtime, string state)
        {

            List<PoPutModel> list = new List<PoPutModel>();
            list = PoPutBLL.ManagePageSelect(ordernumber, starttime, endtime, state);
            return Json(list, JsonRequestBehavior.AllowGet);
        }

        //入库订单删除
        public ActionResult PoPutDelete(string[] ordernumberList) {
            int code = 0;
            string message = "";
            try
            {
                foreach (string item in ordernumberList)
                {
                    if (!PoPutBLL.DeleteByOrdernumber(item)) {
                        message += item + "删除失败！";
                        code += 1;
                    }
                   
                }
                if (code == 0) {
                    message = "删除成功！";
                }
            }
            catch (Exception e)
            {
                code = 1;
                message = "删除失败！(" + e.Message + ")";
            }

            var obj = new
            {
                code = code,
                message = message
            };

            return Json(obj);
        }

        //入库订单审核
        public ActionResult PoPutAuditMethods(string[] ordernumberList)
        {
            int code = 0;
            string message = "审核成功！";

            try
            {
                foreach (string item in ordernumberList)
                {
                    PoPutBLL.PoPutAudit("poput","'"+item+"'","'y'");   
                    //库存添加
                    RepertoryBLL rbll = new RepertoryBLL();
                    rbll.AddRepertory(item,item+"入库单审核入库");
                }
             
            }
            catch (Exception e)
            {
                code = 1;
                message = "审核失败！(" + e.Message + ")";
            }

            var obj = new
            {
                code = code,
                message = message
            };

            return Json(obj);
        }

        /// <summary>
        /// 采购付款页面，返回视图页
        /// </summary>
        /// <returns></returns>
        public ActionResult ProcurementPayView() {
            return View();
        }

    }
}

