﻿using Com.QuanMingBaoFu.ERP.BLL;
using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Com.QuanMingBaoFu.ERP.Controllers
{
    public class WarehouseController : Controller
    {
        PingpaiBLL pingpaibll = new PingpaiBLL();
        KufangBLL bll = new KufangBLL();
        KuquBLL bll2 = new KuquBLL();
        ShopTypeBLL shoptypebll = new ShopTypeBLL();
        CommodityBLL Commoditybll = new CommodityBLL();
        SupplierBLL supplierbll = new SupplierBLL();
        //
        // GET: /Warehouse/
        //库房页面
        public ActionResult kufangAdd()
        {
            List<KufangModel> list = bll.QueryAll();
            return View(list);
        }

        //库房添加
        [HttpPost]
        public ActionResult kufangAdd(string Name, string describe)
        {
            bll.KufangAdd(Name, describe);
            return RedirectToAction("kufangAdd");
        }

        //库区显示页面
        public ActionResult kuquAdd()
        {
            List<KuquModel> list2 = bll2.QueryAll();
            List<KufangModel> list = bll.QueryAll();
            Hashtable model = new Hashtable();
            model.Add("kufang", list);
            model.Add("kuqu", list2);

            return View(model);
        }

        //库区添加
        [HttpPost]
        public ActionResult kuquAddSave(KuquModel model) {
            bll2.AddSave(model); 
            return RedirectToAction("kuquAdd");
        }

        //品牌管理
        public ActionResult pingpaiManage()
        {
            List<PingpaiModel> list = pingpaibll.QueryALL();
            return View(list);
        }

        //品牌添加
        public ActionResult pingpaiAdd(string Name, string Describe, string state)
        {
            PingpaiModel model = new PingpaiModel();
            model.Name = Name;
            model.Describe = Describe;
            model.state = state;
            pingpaibll.Add(model);
            return RedirectToAction("pingpaiManage");
        }

        //商品类型管理
        public ActionResult ShopTypeManage()
        {
            List<ShopTypeModel> list = shoptypebll.QueryALL();
            return View(list);
        }

        //商品类型添加
        public ActionResult ShopTypeAdd(string Name, string Describe, string state)
        {
            ShopTypeModel model = new ShopTypeModel();
            model.Name = Name;
            model.Describe = Describe;
            model.state = state;
            shoptypebll.Add(model);
            return RedirectToAction("ShopTypeManage");
        }

        //商品基本信息维护
        public ActionResult CommodityManage()
        {

            List<ShopTypeModel> type = shoptypebll.QueryALL();
            List<PingpaiModel> pingpai = pingpaibll.QueryALL();
            List<CommodityModel> Commodity = Commoditybll.QueryAll();
            Hashtable model = new Hashtable();
            model.Add("type", type);
            model.Add("pingpai", pingpai);
            model.Add("Commodity", Commodity);

            return View(model);
        }

        //上传商品图片 
        public ActionResult PictureAdd(int ID)
        {
            return View(ID);
        }

        [HttpPost]
        public ActionResult AjaxPictureAdd(HttpPostedFileBase picture, int id)
        {
            string message = "图片上传成功！";
            int code = 0;
            try
            {
                string fileName = picture.FileName;//获取文件名
                string fileFix = fileName.Substring(fileName.LastIndexOf('.')).ToLower();//获取文件后缀
                string filePath = Server.MapPath(string.Format("~/{0}", "Commodityimages"));//图片存放路径
                string newfileName = DateTime.Now.ToString("yyyyMMddHHmmssffff") + fileFix;//新图片名称 
                picture.SaveAs(Path.Combine(filePath, newfileName));
                //更新数据库图片路径
                string url = "/Commodityimages/" + newfileName;
                Commoditybll.UpdatePicture(id, url);
            }
            catch (Exception e)
            {
                code = 1;
                message = e.Message.ToString();
            }
            var obj = new
            {
                code = code,
                message = message
            };

            return Json(obj);
        }


        //商品信息的添加页面
        public ActionResult CommodityAdd()
        {
            List<ShopTypeModel> type = shoptypebll.QueryALL();
            List<PingpaiModel> pingpai = pingpaibll.QueryALL();

            Hashtable model = new Hashtable();
            model.Add("type", type);
            model.Add("pingpai", pingpai);

            return View(model);
        }

        //添加商品
        [HttpPost]
        public ActionResult CommodityAdd(CommodityModel model)
        {
            bool result = Commoditybll.Add(model);
            return RedirectToAction("CommodityManage");
        }


        //供应商显示页面
        public ActionResult SupplierManage()
        {
            List<SupplierModel> list = supplierbll.QueryAll();
            return View(list);
        }

        //供应商添加页面
        public ActionResult SupplierAdd()
        {
            return View();
        }

        //添加供应商
        [HttpPost]
        public ActionResult SupplierAdd(SupplierModel model)
        {

            supplierbll.Add(model);
            return RedirectToAction("SupplierManage");
        }
    }
}
