﻿using Com.QuanMingBaoFu.ERP.DAL;
using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.DLL
{
    public class InformBLL
    {
        //添加通知
        public bool Add(InformModel Inform) {
            return new InformDAL().Add(Inform);
        }

        public List<InformModel> QueryAll() {

            return new InformDAL().QueryAll();
        }
    }
}
