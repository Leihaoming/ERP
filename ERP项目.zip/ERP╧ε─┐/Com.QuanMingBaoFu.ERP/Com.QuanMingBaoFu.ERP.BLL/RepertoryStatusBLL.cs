﻿using Com.QuanMingBaoFu.ERP.DAL;
using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.BLL
{
    public class RepertoryStatusBLL
    {
         /// <summary>
        /// 获取详情
        /// </summary>
        /// <param name="EntrepotID">库房ID</param>
        /// <param name="ReservoirID">库区ID</param>
        /// <returns>List<RepertoryStatusModel></RepertoryStatusModel></returns>
        public List<RepertoryStatusModel> SelectRepertory(int EntrepotID, int ReservoirID)
        {
            return new RepertoryStatusDAL().SelectRepertory(EntrepotID,ReservoirID);
        }
    }
}
