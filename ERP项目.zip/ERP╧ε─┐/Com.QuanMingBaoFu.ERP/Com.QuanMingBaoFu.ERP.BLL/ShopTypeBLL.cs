﻿using Com.QuanMingBaoFu.ERP.DAL;
using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.BLL
{
    public class ShopTypeBLL
    {
        public List<ShopTypeModel> QueryALL() {
            return new ShopTypeDAL().QueryALL();
        }

        public bool Add(ShopTypeModel model)
        {
            return new ShopTypeDAL().Add(model);
        }
    }

}
