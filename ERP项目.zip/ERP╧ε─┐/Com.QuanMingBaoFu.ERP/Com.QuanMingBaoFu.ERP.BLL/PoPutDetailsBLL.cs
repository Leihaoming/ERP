﻿using Com.QuanMingBaoFu.ERP.DAL;
using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.BLL
{
    public class PoPutDetailsBLL
    {
        //根据ordernumber获取入库订单详情
        public static List<PoPutDetailsModel> getOrderNumber(string ordernumber) {
            return PoPutDetailsDAL.getOrderNumber(ordernumber);
        }

           //添加入库详情
        public static bool Add(PoPutDetailsModel model) {
            return PoPutDetailsDAL.Add(model);
        }

    }
}
