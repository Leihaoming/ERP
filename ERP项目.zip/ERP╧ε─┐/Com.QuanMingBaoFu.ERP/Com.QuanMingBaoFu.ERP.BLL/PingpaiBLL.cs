﻿using Com.QuanMingBaoFu.ERP.DAL;
using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.BLL
{
    public class PingpaiBLL
    {
        public List<PingpaiModel> QueryALL() {
            return new PingpaiDAL().QueryALL();
        }

        public bool Add(PingpaiModel model)
        {
            return new PingpaiDAL().Add(model);
        }
    }

}
