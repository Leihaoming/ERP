﻿using Com.QuanMingBaoFu.ERP.DAL;
using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.BLL
{
    public class PoPutBLL
    {
        //通过ordernumber获取订单信息
        public static PoPutModel getordernumber(string ordernumber) {
            return PoPutDAL.getordernumber(ordernumber);
        }

         //添加入库订单（存储过程）
        public static bool Add(PoPutModel model) {
            return PoPutDAL.Add(model);
        }

        //复杂查询
        public static List<PoPutModel> ManagePageSelect(string ordernumber, string starttime, string endtime, string state)
        {
            return PoPutDAL.ManagePageSelect(ordernumber,starttime,endtime,state);
        }
        
        
        //根据订单号删除
        public static bool DeleteByOrdernumber(string ordernumber) {
            return PoPutDAL.DeleteByOrdernumber(ordernumber);
        }

            //审核方法
        public static bool PoPutAudit(string table, string ordernumber, string state)
        {
            return PoPutDAL.PoPutAudit(table,ordernumber,state);
        }

    }
}
