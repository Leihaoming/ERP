﻿using Com.QuanMingBaoFu.ERP.DAL;
using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.BLL
{
    public class KufangBLL
    {
        public bool KufangAdd(string Name, string describe) {
            return new KufangDAL().KufangAdd(Name,describe);
        }

        public List<KufangModel> QueryAll() {
            return new KufangDAL().QueryAll();
        }
    }
}
