﻿using Com.QuanMingBaoFu.ERP.DAL;
using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.BLL
{
   public  class POBLL
    {

       //订单新增
       public bool POAdd(POModel model) {

           return new PODAL().POAdd(model);
       }

       //分页模型
       public PageModel<PoMangeModel> PageQuery(int currentPage, int PageSize, string ordernumb, string starttime, string endtime, string state) {

           PageModel<PoMangeModel> model = new PageModel<PoMangeModel>();
           model.currentPage = currentPage; //当前页
           model.pageSize = PageSize; //每页记录数
           model.list = new PODAL().PoManageQuery(currentPage,PageSize,ordernumb,starttime,endtime,state); //数据集
           model.totalSize = new PODAL().PoNumb(ordernumb,starttime,endtime,state); //总条数
           model.totalPage = model.totalSize % PageSize == 0 ? model.totalSize / PageSize : (model.totalSize / PageSize) + 1; //总页数

           return model;
       
       }


       //根据订单号删除相应记录
       public bool PoDelete(string ordernumber)
       {
           return new PODAL().PoDelete(ordernumber);
       }

       //审核方法
       public bool AuditMethods(string ordernumber)
       {
           return new PODAL().AuditMethods(ordernumber);

       }

        //反审方法，将状态倒置
       public bool reverseMethods(string ordernumber)
       {
           return new PODAL().reverseMethods(ordernumber);
       }

       
         //订单详情页，根据单号查询
       public PoMangeModel getPoModelOrder(string ordernumber)
       {
           return new PODAL().getPoModelOrder(ordernumber);
       }

       //查询指定时间段订单信息
       public List<PoMangeModel> getPotime(string starttime, string endtime, string state) {
           return PODAL.getPotime(starttime,endtime,state);
       }

       
        //采购入库页，根据单号查库房、库区、总额
       public POModel getPoModel(string ordernumber) {
           return PODAL.getPoModel(ordernumber);
       }

       //更新订单状态
       public static bool UpdateState(string table, string ordernumber, string state)
       {
           return PODAL.UpdateState(table,ordernumber,state);
       }
    }
}
