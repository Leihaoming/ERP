﻿using Com.QuanMingBaoFu.ERP.DAL;
using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.BLL
{
    public class POdetailsBLL
    {
        public bool PodetailsAdd(PodetailsModel model)
        {
            return new PodetailsDAL().PodetailsAdd(model);
        }

        //根据订单号删除相应记录
        public bool PodetailsDelete(string ordernumber) {
            return new PodetailsDAL().PodetailsDelete(ordernumber);
        }

          
        //订单详情页，根据单号查详情
        public List<PodetailsModel> getPodetailsModelOrder(string ordernumber)
        {
            return new PodetailsDAL().getPodetailsModelOrder(ordernumber);
        }
    }
}
