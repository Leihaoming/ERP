﻿using Com.QuanMingBaoFu.ERP.DAL;
using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.BLL
{
    public class KuquBLL
    {
        public List<KuquModel> QueryAll() {
            return new KuquDAL().QueryAll();
        }
        public List<KuquModel> QeryKufangID(int id) {
            return new KuquDAL().QeryKufangID(id);
        }
           //库区添加
        public bool AddSave(KuquModel model) {
            return KuquDAL.AddSave(model);
        }
    }
}
