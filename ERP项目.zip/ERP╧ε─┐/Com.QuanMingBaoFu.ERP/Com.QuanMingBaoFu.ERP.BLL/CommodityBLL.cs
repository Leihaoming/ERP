﻿using Com.QuanMingBaoFu.ERP.DAL;
using Com.QuanMingBaoFu.ERP.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.BLL
{
    public class CommodityBLL
    {
        public List<CommodityModel> QueryAll()
        {
            return new CommodityDAL().QueryAll();
        }

        public bool Add(CommodityModel model)
        {

            return new CommodityDAL().Add(model);
        }

        //更新图片路径
        public bool UpdatePicture(int id, string url)
        {

            return new CommodityDAL().UpdatePicture(id, url);
        }
    }
}
