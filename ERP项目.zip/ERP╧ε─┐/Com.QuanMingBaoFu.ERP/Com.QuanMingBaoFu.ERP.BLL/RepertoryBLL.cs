﻿using Com.QuanMingBaoFu.ERP.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.BLL
{
    public class RepertoryBLL
    {
         /// <summary>
        /// 添加库存方法
        /// </summary>
        /// <param name="ordernumber">入库单号</param>
        /// <param name="remark">库存单商品备注信息</param>
        public void AddRepertory(string ordernumber, string remark = "")
        {
             new RepertoryDAL().AddRepertory(ordernumber,remark);
        }
    }
}
