﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.Model
{
    public class RepertoryStatusModel
    {
        public string  CommodityName  { get; set; } //商品名称
        public int CommidityID { get; set; } //商品id
        public int Maximum { get; set; } //最大库存
        public int Minimum { get; set; } //最小库存
        public int Cost { get; set; } //成本
        public string EntrepotName { get; set; } //库房名称
        public string ReservoirName { get; set; } //库区名称
        public int existing { get; set; } //现存量
    }
}
