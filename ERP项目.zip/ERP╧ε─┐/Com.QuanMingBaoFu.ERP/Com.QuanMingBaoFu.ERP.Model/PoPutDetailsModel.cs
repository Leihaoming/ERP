﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.Model
{
    public class PoPutDetailsModel
    {
        public string ordernumber { get; set; } //订单号
        public int CommidityID { get; set; } //商品id
        public int Numble { get; set; } //数量
        public double taxrate { get; set; } //税率
        public double discountrate { get; set; } //折扣率
        public int SupplierID { get; set; } //供应商id
        public double price { get; set; } //商品价格
        public double money { get; set; } //总价
        public string describe { get; set; } //描述
        public string Name { get; set; } //商品名
        public string VendorName { get; set; } //供应商名
    }
}
