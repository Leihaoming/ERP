﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.Model
{
    public class CommodityModel
    {
        public int ID { get; set; } //id
        public string Name { get; set; } //名称
        public int Maximum { get; set; } //最大库存
        public int Minimum { get; set; } //最小库存
        public double Cost { get; set; } //成本
        public double Price { get; set; } //售价
        public int BrandID { get; set; } //品牌id
        public int TypeID { get; set; } //类型id
        public string Color { get; set; } //颜色
        public string unit { get; set; } //单位
        public float Weight { get; set; } //重量
        public string Specification { get; set; } //规格
        public string picture { get; set; } //图片
        public string Texture { get; set; } //材质
        public string rktime { get; set; } //入库时间
        public string sjtime { get; set; } //上架时间
        public string xjtime { get; set; } //下架时间
        public string qhtime { get; set; }//缺货时间
        public string zhrktime { get; set; }//最后入库时间
        public string Describe { get; set; } //描述
      
      

    }
}
