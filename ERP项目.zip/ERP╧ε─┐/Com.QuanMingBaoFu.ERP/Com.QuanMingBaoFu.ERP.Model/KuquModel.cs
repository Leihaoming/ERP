﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.Model
{
     public class KuquModel
    {
         public int ID { get; set; } //库区id
         public string Name { get; set; } //库区名字
         public int EntrepotID { get; set; }//所属库房id
         public string Describe { get; set; }//描述
         public string state { get; set; } //状态
         public string EntrepotName { get; set; } //所属库房名

    }
}
