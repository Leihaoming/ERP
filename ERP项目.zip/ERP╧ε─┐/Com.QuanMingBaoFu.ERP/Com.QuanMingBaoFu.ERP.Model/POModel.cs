﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.Model
{
   public  class POModel
    {
        public string ordernumber { get; set; }
        public string UserName { get; set; } 
        public int UserID { get; set; }
        public string time { get; set; }
        public string qdtime { get; set; }
        public string jhtime { get; set; }
        public int EntrepotID { get; set; }
        public int ReservoirID { get; set; }
        public double money { get; set; }
        public string jhaddress { get; set; }
        public string Describe { get; set; }
        public string state { get; set; }
    }
}
