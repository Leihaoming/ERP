﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.Model
{
    public class RepertoryModel
    {
        public int EntrepotID { get; set; } //库房id
        public int ReservoirID { get; set; } //库区id
        public int CommidityID { get; set; } //商品id
        public int numb { get; set; } //数量
        public string date { get; set; } //操作时间
        public string Remark { get; set; } //备注

    }
}
