﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.Model
{
    public class PageModel<T>
    {
        public int currentPage { get; set; } //当前页
        public int totalPage { get; set; } //总页数
        public int pageSize { get; set; } //每页记录数
        public int totalSize { get; set; } //总的记录数
        public List<T> list { get; set; } //每页数据集合
    }
}
