﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.Model
{
    public class PingpaiModel
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Describe { get; set; }
        public string state { get; set; }

    }
}
