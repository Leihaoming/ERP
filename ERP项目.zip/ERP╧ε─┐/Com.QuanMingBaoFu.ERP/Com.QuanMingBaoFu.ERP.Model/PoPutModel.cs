﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.Model
{
    public class PoPutModel
    {
        public string ordernumber { get; set; } //入库单号
        public int UserID { get; set; } //制单人ID
        public string date { get; set; } //时间
        public string Ponumber { get; set; } //采购单号
        public string rktime { get; set; } //入库时间
        public int EntrepotID { get; set; } //库房id
        public int ReservoirID { get; set; } //库区id
        public double money { get; set; } //总额
        public double yfmoney { get; set; } //已付
        public string type { get; set; } //入库类型
        public string state { get; set; } //状态
        public string remark { get; set; } //备注
        public string UserName { get; set; } //制单人姓名
        public string EntrepotName { get; set; } //库房名
        public string ReservoirName { get; set; } //库区名
    }
}
