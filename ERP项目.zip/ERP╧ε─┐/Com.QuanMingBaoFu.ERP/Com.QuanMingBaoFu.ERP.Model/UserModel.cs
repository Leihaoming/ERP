﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.Model
{
    public class UserModel
    {
        public int ID { get; set; }
        public string UserName { get; set; }
        public string Passworld { get; set; }
        public string RealName { get; set; }
        public string Tel { get; set; }
        public string Sex { get; set; }
        public string QQ { get; set; }
        public int ClassID { get; set; }
        public string State { get; set; }

    }
}
