﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.QuanMingBaoFu.ERP.Model
{
    public class InformModel
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public string Details { get; set; }
        public string Time { get; set; }
        public int Type { get; set; }
        public int UserID { get; set; }
        public string UserName { get; set; }

    }
}
